﻿/**
 * Tripmozy Live Catalog & Direct Booking Engine
 * Auto-synced with Tripmozy.com (Hotels, Prices, Tours, and Checkout integration)
 */
window.TRIPMOZY_HOTELS = [
    {
        "title":  "HOTEL JAMLA INN",
        "url":  "https://tripmozy.com/hotel/hotel-jamla-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/01/unnamed-2026-05-01t114656936.jpg",
        "location":  "Manali",
        "locationId":  13,
        "price":  1495,
        "rating":  4.7
    },
    {
        "title":  "kapoor Resort By DLS Hotels, Manali",
        "url":  "https://tripmozy.com/hotel/kapoor-resort-by-dls-hotels-manali",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/23/unnamed-60.jpg",
        "location":  "Manali",
        "locationId":  13,
        "price":  1379,
        "rating":  4.7
    },
    {
        "title":  "Hotel Devlok By DLS Hotels, Manali",
        "url":  "https://tripmozy.com/hotel/hotel-devlok-by-dls-hotels-manali",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/23/unnamed-49.jpg",
        "location":  "Manali",
        "locationId":  13,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "La Serene Valley by DLS Hotels",
        "url":  "https://tripmozy.com/hotel/la-serene-valley-by-dls-hotels",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/23/unnamed-41.jpg",
        "location":  "Manali",
        "locationId":  13,
        "price":  2299,
        "rating":  4.7
    },
    {
        "title":  "The Bulevar Alpine",
        "url":  "https://tripmozy.com/hotel/the-bulevar-alpine",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/07/unnamed-2026-03-07t114226494.jpg",
        "location":  "Manali",
        "locationId":  13,
        "price":  4600,
        "rating":  4.7
    },
    {
        "title":  "Hotel Valley of Gods",
        "url":  "https://tripmozy.com/hotel/hotel-valley-of-gods",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/05/unnamed-2026-03-05t152300461.jpg",
        "location":  "Manali",
        "locationId":  13,
        "price":  1151,
        "rating":  4.7
    },
    {
        "title":  "Hotel Himalayan Monal Manali",
        "url":  "https://tripmozy.com/hotel/hotel-himalayan-monal-manali",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/28/unnamed-2026-02-28t174616582.jpg",
        "location":  "Manali",
        "locationId":  13,
        "price":  2875,
        "rating":  4.7
    },
    {
        "title":  "Snow Valley Resorts \u0026amp; Spa",
        "url":  "https://tripmozy.com/hotel/manali-snow-valley-resorts-spa",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/01/13/739d3f2e-bf0a-46ce-bc92-9477e5eacab3.jpg",
        "location":  "Manali",
        "locationId":  13,
        "price":  4400,
        "rating":  4.7
    },
    {
        "title":  "Countryard Resort Corbett",
        "url":  "https://tripmozy.com/hotel/countryard-resort-corbett",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/20/exterior-03.JPG",
        "location":  "Manali",
        "locationId":  13,
        "price":  8050,
        "rating":  4.7
    },
    {
        "title":  "UNO PRIME shimla",
        "url":  "https://tripmozy.com/hotel/uno-prime-shimla",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/04/unnamed-2026-05-04t101028480.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  1495,
        "rating":  4.7
    },
    {
        "title":  "Om Niwas Homestay",
        "url":  "https://tripmozy.com/hotel/om-niwas-homestay",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/30/unnamed-2026-04-30t180949833.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  1841,
        "rating":  4.7
    },
    {
        "title":  "DLS Hotels The Rock Castle",
        "url":  "https://tripmozy.com/hotel/dls-hotels-the-rock-castle",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/23/unnamed-28.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  2876,
        "rating":  4.7
    },
    {
        "title":  "DLS Hillcrest Resort",
        "url":  "https://tripmozy.com/hotel/dls-hillcrest-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/23/unnamed-22.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  2875,
        "rating":  4.7
    },
    {
        "title":  "Modi Hotel and Resorts",
        "url":  "https://tripmozy.com/hotel/modi-hotel-and-resorts",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/14/unnamed-2026-03-14t163924960.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  2070,
        "rating":  4.7
    },
    {
        "title":  "Hotel Rock Knob Shimla",
        "url":  "https://tripmozy.com/hotel/hotel-rock-knob-shimla",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/28/unnamed-2026-02-28t1737008511.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  3448,
        "rating":  4.7
    },
    {
        "title":  "Hotel Narayan",
        "url":  "https://tripmozy.com/hotel/hotel-narayan",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/28/unnamed-2026-02-28t172452869.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  2070,
        "rating":  4.7
    },
    {
        "title":  "Shimla Snow Valley Heights",
        "url":  "https://tripmozy.com/hotel/shimla-snow-valley-heights",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/01/14/201506011832595016-1bbe73cb-5348-41e4-aa5d-25dfe1aea57a1.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  6000,
        "rating":  4.7
    },
    {
        "title":  "Shimla Snow Valley Resorts",
        "url":  "https://tripmozy.com/hotel/shimla-snow-valley-resorts",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/01/14/201506011832595016-aaee7de8-d72b-4ee9-a596-0d950f556558.jpg",
        "location":  "Shimla",
        "locationId":  12,
        "price":  5500,
        "rating":  4.7
    },
    {
        "title":  "GardenRetreat",
        "url":  "https://tripmozy.com/hotel/gardenretreat",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/06/unnamed-2026-05-06t164200692.jpg",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "Sherpa  Villa",
        "url":  "https://tripmozy.com/hotel/sherpa-villa",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/04/unnamed-2026-05-04t094335888.jpg",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Ronglyang Lotus Villa Homestay",
        "url":  "https://tripmozy.com/hotel/ronglyang-lotus-villa-homestay",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/01/unnamed-14.png",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  2297,
        "rating":  4.7
    },
    {
        "title":  "The Narayani  Continental",
        "url":  "https://tripmozy.com/hotel/the-narayani-continental",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/01/unnamed-2026-05-01t133207042.jpg",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Temp Heritage Resort",
        "url":  "https://tripmozy.com/hotel/temp-heritage-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/23/unnamed-12.jpg",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  2876,
        "rating":  4.7
    },
    {
        "title":  "Karsonam Hotel",
        "url":  "https://tripmozy.com/hotel/karsonam-hotel",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/16/unnamed-2026-03-16t163247707.jpg",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  2300,
        "rating":  4.7
    },
    {
        "title":  "Dechen and palmo",
        "url":  "https://tripmozy.com/hotel/dechen-and-palmo",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/16/unnamed-2026-03-16t155240655.jpg",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  5175,
        "rating":  4.7
    },
    {
        "title":  "Hotel Bayul",
        "url":  "https://tripmozy.com/hotel/hotel-bayul",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/16/unnamed-2026-03-16t151617484.jpg",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  3335,
        "rating":  4.7
    },
    {
        "title":  "Kanchan Norbo",
        "url":  "https://tripmozy.com/hotel/kanchan-norbo",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/05/unnamed-2026-03-05t110235493.jpg",
        "location":  "Gangtok",
        "locationId":  14,
        "price":  1495,
        "rating":  4.7
    },
    {
        "title":  "Gakhil Boutique Hotel",
        "url":  "https://tripmozy.com/hotel/gakhil-boutique-hotel",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/10/09/hotel1.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  3449,
        "rating":  4.7
    },
    {
        "title":  "Manzil by Mulaqat",
        "url":  "https://tripmozy.com/hotel/manzil-by-mulaqat",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/08/unnamed-2026-05-08t163211480.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  1841,
        "rating":  4.7
    },
    {
        "title":  "Hotel Hill Grand Himalaya",
        "url":  "https://tripmozy.com/hotel/hotel-hill-grand-himalaya",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/06/unnamed-2026-05-06t172310834.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  1381,
        "rating":  4.7
    },
    {
        "title":  "Dik\u0026#039;s  Home",
        "url":  "https://tripmozy.com/hotel/diks-home",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/28/unnamed-2026-04-28t175221004.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "Chhyajalo Homestay",
        "url":  "https://tripmozy.com/hotel/chhyajalo-homestay",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/28/unnamed-2026-04-28t172617555.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "Hotel Rns",
        "url":  "https://tripmozy.com/hotel/hotel-rns",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/28/unnamed-2026-04-28t164410498.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  2071,
        "rating":  4.7
    },
    {
        "title":  "The Revett",
        "url":  "https://tripmozy.com/hotel/the-revett",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/28/unnamed-2026-04-28t154823127.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  1381,
        "rating":  4.7
    },
    {
        "title":  "HOTEL NESSTARA",
        "url":  "https://tripmozy.com/hotel/hotel-nesstara",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/28/unnamed-2026-03-28t141004488.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  1300,
        "rating":  4.7
    },
    {
        "title":  "Hotel Tibet House",
        "url":  "https://tripmozy.com/hotel/hotel-tibet-house",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/16/unnamed-2026-03-16t162016226.jpg",
        "location":  "Darjeeling",
        "locationId":  15,
        "price":  2416,
        "rating":  4.7
    },
    {
        "title":  "Hidden House",
        "url":  "https://tripmozy.com/hotel/hidden-house",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/02/unnamed-2026-03-02t152052815.jpg",
        "location":  "Pelling",
        "locationId":  34,
        "price":  2185,
        "rating":  4.7
    },
    {
        "title":  "Pelling Crest",
        "url":  "https://tripmozy.com/hotel/pelling-crest",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/18/unnamed-2026-02-18t131117868.jpg",
        "location":  "Pelling",
        "locationId":  34,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Maya Eco Huts",
        "url":  "https://tripmozy.com/hotel/maya-eco-huts",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/18/2024-10-17.jpg",
        "location":  "Pelling",
        "locationId":  34,
        "price":  1500,
        "rating":  4.7
    },
    {
        "title":  "Hotel Red Cherry",
        "url":  "https://tripmozy.com/hotel/hotel-red-cherry",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/17/2025-09-22.jpg",
        "location":  "Pelling",
        "locationId":  34,
        "price":  1381,
        "rating":  4.7
    },
    {
        "title":  "Ace Pine Valley",
        "url":  "https://tripmozy.com/hotel/hotel-himsagar",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/20/1c7425e1-ac59-41cb-8446-437f2f68b4621.jpg",
        "location":  "Pelling",
        "locationId":  34,
        "price":  2530,
        "rating":  4.7
    },
    {
        "title":  "Hotel Heruka Inn",
        "url":  "https://tripmozy.com/hotel/hotel-heruka-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/13/9e8f19e8-cabf-4513-930c-f9d63aea1310.jpg",
        "location":  "Pelling",
        "locationId":  34,
        "price":  2760,
        "rating":  4.7
    },
    {
        "title":  "Tripoo Rhisum the Haapo retreat",
        "url":  "https://tripmozy.com/hotel/tripoo-rhisum-the-haapo-retreat",
        "img":  "https://tripmozy.com/uploads/0000/25/2025/09/09/img-67de6f1ff3daf444624551.jpg",
        "location":  "Pelling",
        "locationId":  34,
        "price":  3499,
        "rating":  4.7
    },
    {
        "title":  "Moon Retreat Pelling | Book Luxury Stay at Best Price | TripMozy",
        "url":  "https://tripmozy.com/hotel/the-moon-retreat",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/05/654015060.jpg",
        "location":  "Pelling",
        "locationId":  34,
        "price":  2999,
        "rating":  4.7
    },
    {
        "title":  "Allure De Baranti Resort",
        "url":  "https://tripmozy.com/hotel/allure-de-baranti-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/13/whatsapp-image-2026-02-13-at-110550-am.jpeg",
        "location":  "Purulia",
        "locationId":  16,
        "price":  2587,
        "rating":  4.7
    },
    {
        "title":  "Baranti Manbhum Resort",
        "url":  "https://tripmozy.com/hotel/baranti-manbhum-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/12/unnamed-94.jpg",
        "location":  "Purulia",
        "locationId":  16,
        "price":  1035,
        "rating":  4.7
    },
    {
        "title":  "Hotel Rupashi Bangla",
        "url":  "https://tripmozy.com/hotel/hotel-rupashi-bangla",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/10/07/hotel-rupasi-bangla-10convertcom.jpg",
        "location":  "Purulia",
        "locationId":  16,
        "price":  1700,
        "rating":  4.7
    },
    {
        "title":  "Ajodhya Hill Top Tourist Lodge",
        "url":  "https://tripmozy.com/hotel/ajodhya-hill-top-tourist-lodge",
        "img":  "https://tripmozy.com/uploads/0000/24/2025/09/09/unnamed-16.jpg",
        "location":  "Purulia",
        "locationId":  16,
        "price":  2300,
        "rating":  4.7
    },
    {
        "title":  "Shaljangal Hotel \u0026amp; Resort",
        "url":  "https://tripmozy.com/hotel/shaljangal-hotel-resort",
        "img":  "https://tripmozy.com/uploads/0000/16/2025/09/08/outlook.jpg",
        "location":  "Purulia",
        "locationId":  16,
        "price":  2101,
        "rating":  4.7
    },
    {
        "title":  "Hotel Leisure Palace",
        "url":  "https://tripmozy.com/hotel/hotel-leisure-palace",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/28/unnamed-2026-04-28t182020693.jpg",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  2413,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Premium Mystic Falls",
        "url":  "https://tripmozy.com/hotel/hotel-mystic-falls",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/2025-09-17.png",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  4140,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz The Jungle Resort",
        "url":  "https://tripmozy.com/hotel/hotel-jungle-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/unnamed-9.jpg",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  4830,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Value Alpine retreat",
        "url":  "https://tripmozy.com/hotel/hotel-alpine-retreat",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/2024-08-28.jpg",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  3220,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Premium Laxmi Heritage",
        "url":  "https://tripmozy.com/hotel/hotel-laxmi-heritage",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/unnamed-8.jpg",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  4140,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Value Hills",
        "url":  "https://tripmozy.com/hotel/hotel-value-hills",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/2024-08-10.jpg",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  3680,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Value AIIMS",
        "url":  "https://tripmozy.com/hotel/hotel-value-aiims",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/unnamed-7.jpg",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  805,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Value forest valley",
        "url":  "https://tripmozy.com/hotel/hotel-value-forest-valley",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/unnamed-6.jpg",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  980,
        "rating":  4.7
    },
    {
        "title":  "Hotel Pride Inn",
        "url":  "https://tripmozy.com/hotel/hotel-pride-inn",
        "img":  "https://tripmozy.com/uploads/0000/33/2025/09/10/072addb8-59c5-4d1b-9abc-ab8e2641947c.jpg",
        "location":  "Rishikesh",
        "locationId":  47,
        "price":  2900,
        "rating":  4.7
    },
    {
        "title":  "Hotel Sunshine near Har ki Pauri",
        "url":  "https://tripmozy.com/hotel/hotel-sunshine-near-har-ki-pauri",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/18/unnamed-2026-05-18t115928409.jpg",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  2416,
        "rating":  4.7
    },
    {
        "title":  "Hotel Shivaye",
        "url":  "https://tripmozy.com/hotel/hotel-shivaye",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/08/unnamed-2026-05-08t155753946.jpg",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  1381,
        "rating":  4.7
    },
    {
        "title":  "Hotel Nagpal",
        "url":  "https://tripmozy.com/hotel/hotel-nagpal",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/08/unnamed-2026-05-08t145409181.jpg",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  1265,
        "rating":  4.7
    },
    {
        "title":  "Hotel Mahadev Palace",
        "url":  "https://tripmozy.com/hotel/hotel-mahadev-palace",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/08/unnamed-17.png",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  2071,
        "rating":  4.7
    },
    {
        "title":  "Hotel Royal Central Haridwar",
        "url":  "https://tripmozy.com/hotel/hotel-royal-central-haridwar",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/11/unnamed-2026-03-11t174458762.jpg",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  2070,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Premium Shanti Heritage",
        "url":  "https://tripmozy.com/hotel/hotel-shanti-heritage",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/22/2024-12-24.jpg",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  3220,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Value Aalaya suites",
        "url":  "https://tripmozy.com/hotel/hotel-aalaya-suites",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/22/2025-06-17.jpg",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  3220,
        "rating":  4.7
    },
    {
        "title":  "Hotel Dhruv nanda",
        "url":  "https://tripmozy.com/hotel/hotel-druv-nanda",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/22/unnamed-5.jpg",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  3450,
        "rating":  4.7
    },
    {
        "title":  "Sukoon By Ganges Haridwar",
        "url":  "https://tripmozy.com/hotel/sukoon-by-ganges-haridwar",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/22/2025-02-04.jpg",
        "location":  "Haridwar",
        "locationId":  73,
        "price":  3450,
        "rating":  4.7
    },
    {
        "title":  "Rahul hotel and restaurant",
        "url":  "https://tripmozy.com/hotel/rahul-hotel-and-restaurant",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/27/unnamed-2026-03-27t175924463.jpg",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  3450,
        "rating":  4.7
    },
    {
        "title":  "Hotel Samrat",
        "url":  "https://tripmozy.com/hotel/hotel-samrat",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t171053334.jpg",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "Mussoorie Residency",
        "url":  "https://tripmozy.com/hotel/mussoorie-residency",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t163330146.jpg",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "Hotel Winterline",
        "url":  "https://tripmozy.com/hotel/hotel-winterline",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t155432966.jpg",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  1151,
        "rating":  4.7
    },
    {
        "title":  "Hotel Parkwood",
        "url":  "https://tripmozy.com/hotel/hotel-parkwood",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-18.png",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "Hotel Sunny Cot",
        "url":  "https://tripmozy.com/hotel/hotel-sunny-cot",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t141734806.jpg",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  1037,
        "rating":  4.7
    },
    {
        "title":  "Hotel Shiva Lake",
        "url":  "https://tripmozy.com/hotel/hotel-shiva-lake",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t125936854.jpg",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  1150,
        "rating":  4.7
    },
    {
        "title":  "Hotel Rockland Residency",
        "url":  "https://tripmozy.com/hotel/hotel-rockland-residency",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t121122408.jpg",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  1841,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Value Valley Vista",
        "url":  "https://tripmozy.com/hotel/hotel-value-valley-vista",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/thumbnail.jpg",
        "location":  "Mussoorie",
        "locationId":  74,
        "price":  2759,
        "rating":  4.7
    },
    {
        "title":  "William\u0026#039;s Beach  Retreat",
        "url":  "https://tripmozy.com/hotel/williams-beach-retreat",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/18/unnamed-2026-05-18t121635176.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  1726,
        "rating":  4.7
    },
    {
        "title":  "The Verda de Miranda Resort",
        "url":  "https://tripmozy.com/hotel/the-verda-de-miranda-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/14/unnamed-2026-05-14t132147464.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  2301,
        "rating":  4.7
    },
    {
        "title":  "La Baga Beach Hotel",
        "url":  "https://tripmozy.com/hotel/la-baga-beach-hotel",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t175142192.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  3449,
        "rating":  4.7
    },
    {
        "title":  "Larios Beach Holidays Resort",
        "url":  "https://tripmozy.com/hotel/hotel-manila",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t173316983.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  3450,
        "rating":  4.7
    },
    {
        "title":  "Calangute Beach Resort",
        "url":  "https://tripmozy.com/hotel/calangute-beach-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/12/unnamed-2026-03-12t182521521.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  3106,
        "rating":  4.7
    },
    {
        "title":  "Moustachegoa Luxuria",
        "url":  "https://tripmozy.com/hotel/moustachegoa-luxuria",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/12/unnamed-2026-03-12t171346696.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  3736,
        "rating":  4.7
    },
    {
        "title":  "Casa Pearl By WS",
        "url":  "https://tripmozy.com/hotel/casa-pearl-by-ws",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/12/unnamed-2026-03-12t130559006.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  4025,
        "rating":  4.7
    },
    {
        "title":  "Resort Village Royalw By WS",
        "url":  "https://tripmozy.com/hotel/resort-village-royalw-by-ws",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/12/unnamed-2026-03-12t124634847.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "WS Grand Resort",
        "url":  "https://tripmozy.com/hotel/ws-grand-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/12/unnamed-2026-03-12t115434472.jpg",
        "location":  "Goa",
        "locationId":  48,
        "price":  2990,
        "rating":  4.7
    },
    {
        "title":  "The Cascade Resort Munnar Pool Villa",
        "url":  "https://tripmozy.com/hotel/the-cascade-resort-munnar-pool-villa",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/11/unnamed-2026-04-11t115812623.jpg",
        "location":  "Kerala",
        "locationId":  49,
        "price":  3451,
        "rating":  4.7
    },
    {
        "title":  "Blue Bells Resort",
        "url":  "https://tripmozy.com/hotel/blue-bells-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/10/unnamed-2026-04-10t1722395201.jpg",
        "location":  "Kerala",
        "locationId":  49,
        "price":  2301,
        "rating":  4.7
    },
    {
        "title":  "HOTEL HILLVIEW MUNNAR",
        "url":  "https://tripmozy.com/hotel/hotel-hillview-munnar",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/10/unnamed-2026-04-10t113656673.jpg",
        "location":  "Kerala",
        "locationId":  49,
        "price":  4130,
        "rating":  4.7
    },
    {
        "title":  "Hotel Prasanth",
        "url":  "https://tripmozy.com/hotel/hotel-prasnath",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/11/2021-11-30.jpg",
        "location":  "Kerala",
        "locationId":  49,
        "price":  3220,
        "rating":  4.7
    },
    {
        "title":  "Casa Amari Plantation Resort  Munnar",
        "url":  "https://tripmozy.com/hotel/casa-amari-plantation-resort-munnar",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/13/721a3158-a053-44b5-885d-8c5a70c39db6.jpg",
        "location":  "Kerala",
        "locationId":  49,
        "price":  5300,
        "rating":  4.7
    },
    {
        "title":  "The Cascade Resort Munnar Pool Villa",
        "url":  "https://tripmozy.com/hotel/the-cascade-resort-munnar-pool-villa",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/11/unnamed-2026-04-11t115812623.jpg",
        "location":  "Munnar",
        "locationId":  239,
        "price":  3451,
        "rating":  4.7
    },
    {
        "title":  "Blue Bells Resort",
        "url":  "https://tripmozy.com/hotel/blue-bells-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/10/unnamed-2026-04-10t1722395201.jpg",
        "location":  "Munnar",
        "locationId":  239,
        "price":  2301,
        "rating":  4.7
    },
    {
        "title":  "Hotel V.S. Tanwar",
        "url":  "https://tripmozy.com/hotel/hotel-vs-tanwar",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/16/unnamed-2026-05-16t172258533.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  0,
        "rating":  4.7
    },
    {
        "title":  "Hotel Poonam Palace",
        "url":  "https://tripmozy.com/hotel/hotel-poonam-palace",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/16/unnamed-2026-05-16t165136189.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  1381,
        "rating":  4.7
    },
    {
        "title":  "Hotel Amar Palace",
        "url":  "https://tripmozy.com/hotel/hotel-amar-palace-rajasthan",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/23/2023-08-15-1.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  1724,
        "rating":  4.7
    },
    {
        "title":  "Hotel Siddhi in",
        "url":  "https://tripmozy.com/hotel/hotel-siddhi-in",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/23/unnamed-2026-02-23t115809391.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  1150,
        "rating":  4.7
    },
    {
        "title":  "Hotel Rukmani Palace",
        "url":  "https://tripmozy.com/hotel/hotel-rukmani-palace",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/23/unnamed-2026-02-23t113545590.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  920,
        "rating":  4.7
    },
    {
        "title":  "Hotel SYN",
        "url":  "https://tripmozy.com/hotel/hotel-syn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/21/unnamed-2026-02-21t160334243.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Hotel Ajmer Regency",
        "url":  "https://tripmozy.com/hotel/hotel-ajmer-regency",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/21/unnamed-2026-02-21t153144024.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Hotel Delite",
        "url":  "https://tripmozy.com/hotel/hotel-delite",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/21/2024-08-08-1.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  1726,
        "rating":  4.7
    },
    {
        "title":  "Hotel Bharat Niwas",
        "url":  "https://tripmozy.com/hotel/hotel-bharat-niwas",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/21/unnamed-2026-02-21t125229795.jpg",
        "location":  "Rajasthan",
        "locationId":  44,
        "price":  2069,
        "rating":  4.7
    },
    {
        "title":  "Hotel Life Inn",
        "url":  "https://tripmozy.com/hotel/hotel-life-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/20/2022-02-18.jpg",
        "location":  "Jaipur",
        "locationId":  146,
        "price":  2071,
        "rating":  4.7
    },
    {
        "title":  "Hotel holiday home",
        "url":  "https://tripmozy.com/hotel/hotel-holiday-home",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/20/2020-10-17-2.jpg",
        "location":  "Jaipur",
        "locationId":  146,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "Hotel Marucasa",
        "url":  "https://tripmozy.com/hotel/hotel-marucasa",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/20/2025-06-08.jpg",
        "location":  "Jaipur",
        "locationId":  146,
        "price":  0,
        "rating":  4.7
    },
    {
        "title":  "Hotel Meenakshi",
        "url":  "https://tripmozy.com/hotel/hotel-meenakshi",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/16/2020-11-16.jpg",
        "location":  "Udaipur",
        "locationId":  129,
        "price":  1552,
        "rating":  4.7
    },
    {
        "title":  "Royal Heritage Haveli",
        "url":  "https://tripmozy.com/hotel/royal-heritage-haveli",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/16/2024-11-24.jpg",
        "location":  "Udaipur",
        "locationId":  129,
        "price":  2587,
        "rating":  4.7
    },
    {
        "title":  "Hotel Mewarts",
        "url":  "https://tripmozy.com/hotel/hotel-mewarts",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/14/2025-02-12.jpg",
        "location":  "Udaipur",
        "locationId":  129,
        "price":  2070,
        "rating":  4.7
    },
    {
        "title":  "Hotel MeeraMahal",
        "url":  "https://tripmozy.com/hotel/hotel-meeramahal",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/20/2025-10-01.jpg",
        "location":  "Jaisalmer",
        "locationId":  147,
        "price":  2876,
        "rating":  4.7
    },
    {
        "title":  "Hotel Akashdeep",
        "url":  "https://tripmozy.com/hotel/hotel-akashdeep",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/20/dsc00294-hdr-edit.JPG",
        "location":  "Jaisalmer",
        "locationId":  147,
        "price":  2875,
        "rating":  4.7
    },
    {
        "title":  "Hotel Maheshwar",
        "url":  "https://tripmozy.com/hotel/hotel-maheshwar",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/11/unnamed-2026-03-11t163219503.jpg",
        "location":  "Varanasi",
        "locationId":  76,
        "price":  0,
        "rating":  4.7
    },
    {
        "title":  "Hotel Blue star Varanasi",
        "url":  "https://tripmozy.com/hotel/hotel-blue-star",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/04/e38549a0947211ea86db0242ac110003.jpg",
        "location":  "Varanasi",
        "locationId":  76,
        "price":  1350,
        "rating":  4.7
    },
    {
        "title":  "Perfectstayz Premium Varanasi",
        "url":  "https://tripmozy.com/hotel/perfectstayz-premium-varanasi",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/23/unnamed-12.jpg",
        "location":  "Varanasi",
        "locationId":  76,
        "price":  2875,
        "rating":  4.7
    },
    {
        "title":  "Raghuveer Sadan",
        "url":  "https://tripmozy.com/hotel/raghuveer-sadan",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/13/unnamed-2026-03-13t115251472.jpg",
        "location":  "Ayodhya",
        "locationId":  46,
        "price":  2070,
        "rating":  4.7
    },
    {
        "title":  "Vasu Palace",
        "url":  "https://tripmozy.com/hotel/vasu-palace",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/12/unnamed-2026-03-12t161742146.jpg",
        "location":  "Ayodhya",
        "locationId":  46,
        "price":  2875,
        "rating":  4.7
    },
    {
        "title":  "Manas Inn",
        "url":  "https://tripmozy.com/hotel/manas-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/12/unnamed-2026-03-12t145435359.jpg",
        "location":  "Ayodhya",
        "locationId":  46,
        "price":  1841,
        "rating":  4.7
    },
    {
        "title":  "Vatsalya Bhawan",
        "url":  "https://tripmozy.com/hotel/vatsalya-bhawan",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/11/unnamed-2026-03-11t123021768.jpg",
        "location":  "Ayodhya",
        "locationId":  46,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Hotel Sahu Inn",
        "url":  "https://tripmozy.com/hotel/hotel-sahu-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/10/unnamed-2026-03-10t174221849.jpg",
        "location":  "Ayodhya",
        "locationId":  46,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "HOTEL KANAK KUTEER",
        "url":  "https://tripmozy.com/hotel/hotel-kanak-kuteer",
        "img":  "https://tripmozy.com/uploads/0000/34/2025/09/10/2025-01-11.jpg",
        "location":  "Ayodhya",
        "locationId":  46,
        "price":  2100,
        "rating":  4.7
    },
    {
        "title":  "Hotel Goyal Palace",
        "url":  "https://tripmozy.com/hotel/hotel-goyal-palace",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/31/unnamed-2026-03-31t163652273.jpg",
        "location":  "Agra",
        "locationId":  226,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Hotel riya Palace",
        "url":  "https://tripmozy.com/hotel/hotel-riya-palace",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/31/unnamed-2026-03-31t152604066.jpg",
        "location":  "Agra",
        "locationId":  226,
        "price":  1266,
        "rating":  4.7
    },
    {
        "title":  "D Meadows",
        "url":  "https://tripmozy.com/hotel/d-meadows",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/27/unnamed-2026-02-27t171804428.jpg",
        "location":  "Leh Ladakh",
        "locationId":  82,
        "price":  10350,
        "rating":  4.7
    },
    {
        "title":  "The Bodhi Tree Hotel",
        "url":  "https://tripmozy.com/hotel/the-bodhi-tree-hotel",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/27/unnamed-2026-02-27t154338565.jpg",
        "location":  "Leh Ladakh",
        "locationId":  82,
        "price":  7071,
        "rating":  4.7
    },
    {
        "title":  "Zen Ladakh",
        "url":  "https://tripmozy.com/hotel/zen-ladakh",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/27/unnamed-2026-02-27t152015880.jpg",
        "location":  "Leh Ladakh",
        "locationId":  82,
        "price":  16191,
        "rating":  4.7
    },
    {
        "title":  "Hotel Padma Ladakh",
        "url":  "https://tripmozy.com/hotel/hotel-padma-ladakh",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/27/unnamed-2026-02-27t145522332.jpg",
        "location":  "Leh Ladakh",
        "locationId":  82,
        "price":  6290,
        "rating":  4.7
    },
    {
        "title":  "Hotel Outlook",
        "url":  "https://tripmozy.com/hotel/hotel-outlook",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/26/unnamed-2026-02-26t153502169.jpg",
        "location":  "Kashmir",
        "locationId":  43,
        "price":  5176,
        "rating":  4.7
    },
    {
        "title":  "Jai  Ma Inn",
        "url":  "https://tripmozy.com/hotel/jai-ma-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/26/unnamed.png",
        "location":  "Kashmir",
        "locationId":  43,
        "price":  2185,
        "rating":  4.7
    },
    {
        "title":  "Hotel Raghunath Jammu",
        "url":  "https://tripmozy.com/hotel/hotel-raghunath-jammu",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/26/unnamed-2026-02-26t114513339.jpg",
        "location":  "Kashmir",
        "locationId":  43,
        "price":  1850,
        "rating":  4.7
    },
    {
        "title":  "Clarks Inn Express Jammu",
        "url":  "https://tripmozy.com/hotel/clarks-inn-express-jammu",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/26/unnamed-2026-02-26t112549468.jpg",
        "location":  "Kashmir",
        "locationId":  43,
        "price":  3221,
        "rating":  4.7
    },
    {
        "title":  "The aura inn hotel",
        "url":  "https://tripmozy.com/hotel/the-aura-inn-hotel",
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/16/gallery-9d82d12505bc86181523792aa23fa681.jpg",
        "location":  "Kashmir",
        "locationId":  43,
        "price":  4024,
        "rating":  4.7
    },
    {
        "title":  "Shyamajyoti Hotel",
        "url":  "https://tripmozy.com/hotel/shyamajyoti-hotel",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/04/unnamed-2026-04-04t1529579161.jpg",
        "location":  "Puri",
        "locationId":  17,
        "price":  1841,
        "rating":  4.7
    },
    {
        "title":  "Hotel Beach Comforts",
        "url":  "https://tripmozy.com/hotel/hotel-beach-comforts",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/09/unnamed-2026-03-09t172427351.jpg",
        "location":  "Puri",
        "locationId":  17,
        "price":  1956,
        "rating":  4.7
    },
    {
        "title":  "Hello By Ananya",
        "url":  "https://tripmozy.com/hotel/hello-by-ananya",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/01/31/5d6520a800b111ee8a1e0a58a9feac02.jpg",
        "location":  "Puri",
        "locationId":  17,
        "price":  1455,
        "rating":  4.7
    },
    {
        "title":  "Hotel Arya Palace Puri",
        "url":  "https://tripmozy.com/hotel/hotel-arya-palace-puri",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/01/30/hotel-front.jpg",
        "location":  "Puri",
        "locationId":  17,
        "price":  1610,
        "rating":  4.7
    },
    {
        "title":  "Sk Residency Puri",
        "url":  "https://tripmozy.com/hotel/sk-residency-puri",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/01/13/7edfeef9-c9f4-40b9-ae74-b0741ab5f7a1.jpg",
        "location":  "Puri",
        "locationId":  17,
        "price":  950,
        "rating":  4.7
    },
    {
        "title":  "Hotel Sahiti",
        "url":  "https://tripmozy.com/hotel/hotel-sahiti",
        "img":  "https://tripmozy.com/uploads/0000/31/2025/09/10/a5d43cb5-850b-407d-be2d-898a98a61599.jpg",
        "location":  "Puri",
        "locationId":  17,
        "price":  4051,
        "rating":  4.7
    },
    {
        "title":  "Hotel Skyking",
        "url":  "https://tripmozy.com/hotel/hotel-skyking",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/19/unnamed-2026-03-19t164856314.jpg",
        "location":  "Kolkata",
        "locationId":  11,
        "price":  2128,
        "rating":  4.7
    },
    {
        "title":  "The Chorus Inn",
        "url":  "https://tripmozy.com/hotel/the-chorus-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/17/unnamed-2026-03-17t143816786.jpg",
        "location":  "Kolkata",
        "locationId":  11,
        "price":  1611,
        "rating":  4.7
    },
    {
        "title":  "Golden Heaven Hotel and Restuarant",
        "url":  "https://tripmozy.com/hotel/golden-heaven-hotel-and-restuarant",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/11/unnamed-11.png",
        "location":  "Kolkata",
        "locationId":  11,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Hotel Ananya",
        "url":  "https://tripmozy.com/hotel/hotel-ananya",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/25/unnamed-2026-03-25t172155908.jpg",
        "location":  "Digha",
        "locationId":  18,
        "price":  7821,
        "rating":  4.7
    },
    {
        "title":  "Hotel GC International",
        "url":  "https://tripmozy.com/hotel/hotel-gc-international",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/25/unnamed-2026-03-25t160112242.jpg",
        "location":  "Digha",
        "locationId":  18,
        "price":  2300,
        "rating":  4.7
    },
    {
        "title":  "Hotel Shantiniketan",
        "url":  "https://tripmozy.com/hotel/hotel-shantiniketan",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/25/unnamed-2026-03-25t154042623.jpg",
        "location":  "Digha",
        "locationId":  18,
        "price":  977,
        "rating":  4.7
    },
    {
        "title":  "Hotel Dolphin",
        "url":  "https://tripmozy.com/hotel/hotel-dolphin",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/25/unnamed-2026-03-25t151025792.jpg",
        "location":  "Digha",
        "locationId":  18,
        "price":  3911,
        "rating":  4.7
    },
    {
        "title":  "Maa durga guest inn",
        "url":  "https://tripmozy.com/hotel/maa-durga-guest-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/25/unnamed-2026-03-25t130922210.jpg",
        "location":  "Digha",
        "locationId":  18,
        "price":  2300,
        "rating":  4.7
    },
    {
        "title":  "Hotel Royal paradise",
        "url":  "https://tripmozy.com/hotel/hotel-royal-paradise",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/25/unnamed-2026-03-25t124321294.jpg",
        "location":  "Digha",
        "locationId":  18,
        "price":  1725,
        "rating":  4.7
    },
    {
        "title":  "Royal Sea View",
        "url":  "https://tripmozy.com/hotel/royal-sea-view",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/25/unnamed-2026-03-25t114623951.jpg",
        "location":  "Digha",
        "locationId":  18,
        "price":  2243,
        "rating":  4.7
    },
    {
        "title":  "Hotel Rupkatha Mandarmani",
        "url":  "https://tripmozy.com/hotel/hotel-rupkatha-mandarmani",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/28/unnamed-2026-03-28t162844846.jpg",
        "location":  "Mandarmoni",
        "locationId":  19,
        "price":  1841,
        "rating":  4.7
    },
    {
        "title":  "Blue Stone",
        "url":  "https://tripmozy.com/hotel/blue-stone",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/28/unnamed-2026-03-28t154619021.jpg",
        "location":  "Mandarmoni",
        "locationId":  19,
        "price":  1500,
        "rating":  4.7
    },
    {
        "title":  "The Sea Horse",
        "url":  "https://tripmozy.com/hotel/the-sea-horse",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/28/unnamed-2026-03-28t150819209.jpg",
        "location":  "Mandarmoni",
        "locationId":  19,
        "price":  2070,
        "rating":  4.7
    },
    {
        "title":  "The Pelican Beach Resort",
        "url":  "https://tripmozy.com/hotel/the-pelican-beach-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/25/unnamed-2026-02-25t122138943.jpg",
        "location":  "Mandarmoni",
        "locationId":  19,
        "price":  2070,
        "rating":  4.7
    },
    {
        "title":  "Hotel Deep Forest",
        "url":  "https://tripmozy.com/hotel/hotel-deep-forest",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/07/unnamed-2026-04-07t105127673.jpg",
        "location":  "Kasol",
        "locationId":  230,
        "price":  1726,
        "rating":  4.7
    },
    {
        "title":  "Napland",
        "url":  "https://tripmozy.com/hotel/napland",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/06/unnamed-2026-04-06t173433630.jpg",
        "location":  "Kasol",
        "locationId":  230,
        "price":  1841,
        "rating":  4.7
    },
    {
        "title":  "Lee  Garden Himalayan Wooden Cottage",
        "url":  "https://tripmozy.com/hotel/lee-garden-himalayan-wooden-cottage",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/06/unnamed-2026-04-06t164811714.jpg",
        "location":  "Kasol",
        "locationId":  230,
        "price":  1150,
        "rating":  4.7
    },
    {
        "title":  "Hotel Snow Retreat",
        "url":  "https://tripmozy.com/hotel/hotel-snow-retreat",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/24/unnamed-5.png",
        "location":  "Dharamshala",
        "locationId":  182,
        "price":  1152,
        "rating":  4.7
    },
    {
        "title":  "Anupam Resort By DLS Hotels, Naddi",
        "url":  "https://tripmozy.com/hotel/anupam-resort-by-dls-hotels-naddi",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/24/unnamed-83.jpg",
        "location":  "Dharamshala",
        "locationId":  182,
        "price":  2301,
        "rating":  4.7
    },
    {
        "title":  "Hotel Shiva Sanctuary by DLS Hotels, McLeod Ganj",
        "url":  "https://tripmozy.com/hotel/hotel-shiva-sanctuary-by-dls-hotels-mcleod-ganj",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/24/unnamed-76.jpg",
        "location":  "Dharamshala",
        "locationId":  182,
        "price":  2301,
        "rating":  4.7
    },
    {
        "title":  "Spring Valley Spa Resort by DLS Hotels",
        "url":  "https://tripmozy.com/hotel/spring-valley-spa-resort-by-dls-hotels",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/23/unnamed-70.jpg",
        "location":  "Dharamshala",
        "locationId":  182,
        "price":  3451,
        "rating":  4.7
    },
    {
        "title":  "DLS Meghavan Resort",
        "url":  "https://tripmozy.com/hotel/dls-meghavan-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/23/unnamed-64.jpg",
        "location":  "Dharamshala",
        "locationId":  182,
        "price":  3451,
        "rating":  4.7
    },
    {
        "title":  "Hotel RC Regency",
        "url":  "https://tripmozy.com/hotel/hotel-rc-regency",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/28/unnamed-2026-02-28t164516653.jpg",
        "location":  "Dharamshala",
        "locationId":  182,
        "price":  1841,
        "rating":  4.7
    },
    {
        "title":  "Hotel Triund Heights",
        "url":  "https://tripmozy.com/hotel/hotel-triund-heights",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/28/unnamed-2026-02-28t160604076.jpg",
        "location":  "Dharamshala",
        "locationId":  182,
        "price":  3220,
        "rating":  4.7
    },
    {
        "title":  "Delightz Inn",
        "url":  "https://tripmozy.com/hotel/delightz-inn",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/13/unnamed-2026-02-13t163028912.jpg",
        "location":  "Ooty",
        "locationId":  124,
        "price":  6900,
        "rating":  4.7
    },
    {
        "title":  "Deccan Park Resort",
        "url":  "https://tripmozy.com/hotel/deccan-park-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/13/2024-08-29.jpg",
        "location":  "Ooty",
        "locationId":  124,
        "price":  5175,
        "rating":  4.7
    },
    {
        "title":  "Lily\u0026#039;s Valley Resort",
        "url":  "https://tripmozy.com/hotel/liys-valley-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/13/2025-02-24.jpg",
        "location":  "Kodaikanal",
        "locationId":  125,
        "price":  6843,
        "rating":  4.7
    },
    {
        "title":  "Archana Guest House",
        "url":  "https://tripmozy.com/hotel/archana-guest-house",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/04/10/unnamed-2026-04-10t155501049.jpg",
        "location":  "Hampi",
        "locationId":  238,
        "price":  1726,
        "rating":  4.7
    },
    {
        "title":  "UNO ELITE AMRITSAR",
        "url":  "https://tripmozy.com/hotel/uno-elite-amritsar",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/05/01/unnamed-2026-05-01t122721075.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  1726,
        "rating":  4.7
    },
    {
        "title":  "5 States Resort",
        "url":  "https://tripmozy.com/hotel/5-states-resort",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/30/unnamed-2026-03-30t175257880.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  3105,
        "rating":  4.7
    },
    {
        "title":  "DLS Hotels Amritsar",
        "url":  "https://tripmozy.com/hotel/dls-hotels-amritsar",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/03/24/unnamed-2026-03-24t164646824.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  3451,
        "rating":  4.7
    },
    {
        "title":  "HOTEL Puri Palace",
        "url":  "https://tripmozy.com/hotel/hotel-puri-palace",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/24/unnamed-2026-02-24t115006234.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  2300,
        "rating":  4.7
    },
    {
        "title":  "The Park View",
        "url":  "https://tripmozy.com/hotel/the-park-view",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/24/unnamed-2026-02-24t111410860.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  1264,
        "rating":  4.7
    },
    {
        "title":  "Hotel Kings",
        "url":  "https://tripmozy.com/hotel/hotel-kings",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/23/unnamed-2026-02-23t174245720.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  1200,
        "rating":  4.7
    },
    {
        "title":  "Hotel Sehdev Residency",
        "url":  "https://tripmozy.com/hotel/hotel-sehdev-residency",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/23/unnamed-2026-02-23t171420300.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  1380,
        "rating":  4.7
    },
    {
        "title":  "Hotel Lemonade",
        "url":  "https://tripmozy.com/hotel/hotel-lemonade",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/23/2025-07-06.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  1207,
        "rating":  4.7
    },
    {
        "title":  "Hotel Grand Fortune",
        "url":  "https://tripmozy.com/hotel/hotel-grand-fortune",
        "img":  "https://tripmozy.com/uploads/0000/7/2026/02/23/2024-06-21.jpg",
        "location":  "Amritsar",
        "locationId":  75,
        "price":  1499,
        "rating":  4.7
    }
]
;

window.TRIPMOZY_TOURS = [
    {
        "location":  "Manali",
        "duration":  "4 Days / 3 Nights",
        "category":  "Himalayan Trek",
        "price":  7500,
        "img":  "https://tripmozy.com/uploads/0000/7/2025/10/03/brahmtal-trek.jpg",
        "title":  "Beas Kund Trek (Manali)",
        "url":  "https://tripmozy.com/tour/beas-kund-trek-1"
    },
    {
        "location":  "Kashmir",
        "duration":  "7 Days / 6 Nights",
        "category":  "Scenic Paradise",
        "price":  18999,
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/08/unnamed-13.jpg",
        "title":  "Tulip, Doodhpathri \u0026 Pahalgam Kashmir Tour",
        "url":  "https://tripmozy.com/tour/tulip-doodhpathri-pahalgam-vaishnodevil-tour-bose-tourism"
    },
    {
        "location":  "Uttarakhand",
        "duration":  "5 Days / 4 Nights",
        "category":  "Snow Peak Trek",
        "price":  8000,
        "img":  "https://tripmozy.com/uploads/0000/7/2025/10/03/kedarkantha-trek.jpg",
        "title":  "Kedarkantha Winter Snow Trek",
        "url":  "https://tripmozy.com/tour/kedarkantha-trek"
    },
    {
        "location":  "Darjeeling",
        "duration":  "6 Days / 5 Nights",
        "category":  "Eastern Himalayas",
        "price":  14500,
        "img":  "https://tripmozy.com/uploads/0000/7/2025/10/03/11000-2.jpg",
        "title":  "Sandakphu \u0026 Singalila Ridge Tour",
        "url":  "https://tripmozy.com/tour/sandakphu-tour-package"
    },
    {
        "location":  "Varanasi",
        "duration":  "5 Days / 4 Nights",
        "category":  "Spiritual \u0026 Heritage",
        "price":  13500,
        "img":  "https://tripmozy.com/uploads/0000/7/2025/09/08/unnamed-11.jpg",
        "title":  "Varanasi, Ayodhya \u0026 Lucknow Heritage Circuit",
        "url":  "https://tripmozy.com/tour/varanasi-lucknow-ayodhya"
    },
    {
        "location":  "Rishikesh",
        "duration":  "7 Days / 6 Nights",
        "category":  "Ancient Valley Trek",
        "price":  12500,
        "img":  "https://tripmozy.com/uploads/0000/7/2025/10/03/11000-3.jpg",
        "title":  "Har Ki Dun Valley of Gods Trek",
        "url":  "https://tripmozy.com/tour/har-ki-dun-trek"
    },
    {
        "location":  "Uttarakhand",
        "duration":  "8 Days / 7 Nights",
        "category":  "High Altitude",
        "price":  21000,
        "img":  "https://tripmozy.com/uploads/0000/7/2025/10/03/11000-2.jpg",
        "title":  "Roopkund Mystery Lake Trek",
        "url":  "https://tripmozy.com/tour/roopkund-trek"
    },
    {
        "location":  "Uttarakhand",
        "duration":  "6 Days / 5 Nights",
        "category":  "Mountain Panorama",
        "price":  9000,
        "img":  "https://tripmozy.com/uploads/0000/7/2025/10/03/kauri-pass.jpg",
        "title":  "Kuari Pass Lord Curzon Trail Trek",
        "url":  "https://tripmozy.com/tour/kuari-pass-trek"
    }
];

/**
 * Find Tripmozy verified hotels for a given Indian destination query
 */
window.getTripmozyHotelsForLocation = function(destinationName) {
  if (!destinationName) return window.TRIPMOZY_HOTELS.slice(0, 6);
  var q = destinationName.toLowerCase().trim();
  
  // Direct match
  var matches = window.TRIPMOZY_HOTELS.filter(function(h) {
    var loc = (h.location || '').toLowerCase();
    var tit = (h.title || '').toLowerCase();
    return q.indexOf(loc) !== -1 || loc.indexOf(q) !== -1 || tit.indexOf(q) !== -1;
  });

  // Circuit fallback (e.g. Solang -> Manali, Fort Aguada -> Goa, Munnar -> Kerala)
  if (matches.length === 0) {
    if (q.indexOf('manali') !== -1 || q.indexOf('solang') !== -1 || q.indexOf('kullu') !== -1 || q.indexOf('rohtang') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Manali'; });
    } else if (q.indexOf('goa') !== -1 || q.indexOf('calangute') !== -1 || q.indexOf('panaji') !== -1 || q.indexOf('baga') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Goa'; });
    } else if (q.indexOf('munnar') !== -1 || q.indexOf('kerala') !== -1 || q.indexOf('alleppey') !== -1 || q.indexOf('kochi') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Kerala' || h.location === 'Munnar'; });
    } else if (q.indexOf('jaipur') !== -1 || q.indexOf('rajasthan') !== -1 || q.indexOf('udaipur') !== -1 || q.indexOf('jodhpur') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Rajasthan' || h.location === 'Jaipur' || h.location === 'Udaipur'; });
    } else if (q.indexOf('gangtok') !== -1 || q.indexOf('sikkim') !== -1 || q.indexOf('pelling') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Gangtok' || h.location === 'Pelling'; });
    } else if (q.indexOf('darjeeling') !== -1 || q.indexOf('mirik') !== -1 || q.indexOf('kurseong') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Darjeeling'; });
    } else if (q.indexOf('rishikesh') !== -1 || q.indexOf('haridwar') !== -1 || q.indexOf('uttarakhand') !== -1 || q.indexOf('mussoorie') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Rishikesh' || h.location === 'Haridwar' || h.location === 'Mussoorie'; });
    } else if (q.indexOf('varanasi') !== -1 || q.indexOf('ayodhya') !== -1 || q.indexOf('kashi') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Varanasi' || h.location === 'Ayodhya'; });
    } else if (q.indexOf('digha') !== -1 || q.indexOf('mandarmani') !== -1 || q.indexOf('mandarmoni') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Digha' || h.location === 'Mandarmoni'; });
    } else if (q.indexOf('purulia') !== -1 || q.indexOf('barhanti') !== -1 || q.indexOf('ayodhya hill') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Purulia'; });
    } else if (q.indexOf('kashmir') !== -1 || q.indexOf('srinagar') !== -1 || q.indexOf('gulmarg') !== -1 || q.indexOf('pahalgam') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Kashmir'; });
    } else if (q.indexOf('ladakh') !== -1 || q.indexOf('leh') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Leh Ladakh'; });
    } else if (q.indexOf('amritsar') !== -1 || q.indexOf('golden temple') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Amritsar'; });
    } else if (q.indexOf('ooty') !== -1 || q.indexOf('kodaikanal') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Ooty' || h.location === 'Kodaikanal'; });
    } else if (q.indexOf('hampi') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Hampi'; });
    } else if (q.indexOf('puri') !== -1 || q.indexOf('odisha') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Puri'; });
    } else if (q.indexOf('kasol') !== -1 || q.indexOf('parvati') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Kasol'; });
    } else if (q.indexOf('dharamshala') !== -1 || q.indexOf('mcleod') !== -1) {
      matches = window.TRIPMOZY_HOTELS.filter(function(h) { return h.location === 'Dharamshala'; });
    }
  }

  return matches.length > 0 ? matches : window.TRIPMOZY_HOTELS.slice(0, 6);
};

/**
 * Find Tripmozy latest tours and treks related to destination
 */
window.getTripmozyToursForLocation = function(destinationName) {
  if (!destinationName) return window.TRIPMOZY_TOURS.slice(0, 3);
  var q = destinationName.toLowerCase().trim();
  var matches = window.TRIPMOZY_TOURS.filter(function(t) {
    var loc = (t.location || '').toLowerCase();
    var tit = (t.title || '').toLowerCase();
    return q.indexOf(loc) !== -1 || loc.indexOf(q) !== -1 || tit.indexOf(q) !== -1;
  });
  return matches.length > 0 ? matches : window.TRIPMOZY_TOURS.slice(0, 3);
};
